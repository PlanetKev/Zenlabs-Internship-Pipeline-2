# organizing imports
import cv2
import numpy as np

# path to input image is specified and
# image is loaded with imread command
image1 = cv2.imread('/Users/Kevin/PycharmProjects/MLIntern2ndPipeline/Images/scissor/1.jpeg')

# cv2.cvtColor is applied over the
# image input with applied parameters
# to convert the image in grayscrale
img = cv2.cvtColor(image1, cv2.COLOR_BGR2GRAY)

# applying different thresholding
# techniques on the input image
thresh1 = cv2.adaptiveThreshold(img, 255, cv2.ADAPTIVE_THRESH_MEAN_C,
                                cv2.THRESH_BINARY, 199, 0)

thresh2 = cv2.adaptiveThreshold(img, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                cv2.THRESH_BINARY, 199, 5)
cv2.imwrite('Mean_mod1.png', thresh1)
cv2.imwrite('Gaussian_mod2.png', thresh2)
