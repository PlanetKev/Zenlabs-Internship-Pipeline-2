#
import imutils
import cv2
import argparse
import numpy as np
import time
import matplotlib.pyplot as plt
count=0


import PIL
from PIL import Image

def resize_image(image, my_width = 30):
    # first calculate the ratio of the *new* width to the *old* width
    r = float(my_width) / image.shape[1]
    dim = (my_width, int(image.shape[0] * r))
    # perform the actual resizing of the image
    resized = cv2.resize(image, dim, interpolation=cv2.INTER_AREA)

    
    return resized

def get_contours(img):
    """Get connected domain

         :param img: input picture
         :return: Maximum connected domain
    """
    # Grayscale, binarization, connected domain analysis
#     cv2.imwrite("image.png", img)
    img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    # img_gray, g, r = cv2.split(img)
    ret, img_bin = cv2.threshold(img_gray, 150, 255, cv2.THRESH_BINARY)
#     cv2.imwrite("img_gray.png", img_bin)
    contours, hierarcahy = cv2.findContours(img_bin, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
    if len(contours[0])>1:
        return contours[0]
    else:
        return None


def gethaudroffdistance(window):
    global count
    
    # 1. Import pictures
    img_cs1 = window

    #     img_cs2 = cv2.imread("scissor_parts (1).png")
    #     print(img_cs2.shape)
#     img_cs2 = cv2.imread("cluttered-desk_1.jpg")
#     img_cs2 = resize_image(cv2.imread("scissor_parts (1).png"))
    img_cs2 = resize_image(cv2.imread("/Users/Kevin/PycharmProjects/MLIntern2ndPipeline/Images/Images/Screenshot 2021-05-11 at 11.18.11 AM.png"))

    # 2. Get the connected domain of the picture
    cnt_cs1 = get_contours(img_cs1)
    cnt_cs2 = get_contours(img_cs2)
#     print(len(cnt_cs1), len(cnt_cs2))
    if (cnt_cs1 is not None) and (cnt_cs2 is not None):
        # 3. Create a distance object
        hausdorff_sd = cv2.createHausdorffDistanceExtractor()

        #     # 4. Calculate the distance between contours

    #     d1 = hausdorff_sd.computeDistance(cnt_cs1, cnt_cs2)
        d1 = hausdorff_sd.computeDistance(cnt_cs1, cnt_cs2)
        if d1>150:
            count=count+1
            cv2.imwrite("img"+str(count)+".png", window)
            print(True, count, d1)
            return True
        else:
            return False


def pyramid(image, scale=1.5, minSize=(30, 30)):
    # yield the original image
    yield image
    # keep looping over the pyramid
    while True:
        print("scale")
        # compute the new dimensions of the image and resize it
        w = int(image.shape[1] / scale)
        image = imutils.resize(image, width=w)
        # if the resized image does not meet the supplied minimum
        # size, then stop constructing the pyramid
        if image.shape[0] < minSize[1] or image.shape[1] < minSize[0]:
            break
        # yield the next image in the pyramid
        yield image


def sliding_window(image, stepSize, windowSize):
    # slide a window across the image
    for y in range(0, image.shape[0], stepSize):
        for x in range(0, image.shape[1], stepSize):
            # yield the current window
            yield (x, y, image[y:y + windowSize[1], x:x + windowSize[0]])

def main():
    # img1 = cv2.imread("/Users/Kevin/PycharmProjects/MLIntern2ndPipeline/Images/scissor/1.jpeg")
    # image = cv2.imread("cluttered-desk.jpg")
    image = cv2.imread("/Users/Kevin/PycharmProjects/MLIntern2ndPipeline/Images/scissor/1.jpeg")
    (winW, winH) = (128, 128)
    a = []
    for resized in pyramid(image, scale=1.5):
        # loop over the sliding window for each layer of the pyramid

        for (x, y, window) in sliding_window(resized, stepSize=25, windowSize=(winW, winH)):
            # if the window does not meet our desired window size, ignore it
            if window.shape[0] != winH or window.shape[1] != winW:
              continue
            # THIS IS WHERE YOU WOULD PROCESS YOUR WINDOW, SUCH AS APPLYING A
            # MACHINE LEARNING CLASSIFIER TO CLASSIFY THE CONTENTS OF THE
            # WINDOW
            # since we do not have a classifier, we'll just draw the window

            status = gethaudroffdistance(window)
            clone = resized.copy()
            clone1 = resized.copy()
            cv2.rectangle(clone, (x, y), (x + winW, y + winH), (0, 255, 0), 2)

            if status is True:
                a.append([x, y, x + winW, y + winH])


            cv2.imshow("Window", clone)
            cv2.waitKey(1)
            time.sleep(0.025)
    print(a)

if __name__ == '__main__':
    main()
