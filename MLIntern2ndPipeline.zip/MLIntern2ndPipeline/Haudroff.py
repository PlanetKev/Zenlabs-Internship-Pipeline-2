#
import cv2
import matplotlib.pyplot as plt


def get_contours(img):
    """Get connected domain

         :param img: input picture
         :return: Maximum connected domain
    """
    # Grayscale, binarization, connected domain analysis
    img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    ret, img_bin = cv2.threshold(img_gray, 200, 255, cv2.THRESH_BINARY)
    contours, hierarchy = cv2.findContours(img_bin, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)

    return contours[0]


def main():
    # 1. Import pictures
    img_cs1 = cv2.imread("/Users/Kevin/PycharmProjects/MLIntern2ndPipeline/Images/scissor/1.jpeg")
    print(img_cs1.shape)
    #     img_cs2 = cv2.imread("scissor_parts (1).png")
    #     print(img_cs2.shape)
    img_cs2 = cv2.imread("/Users/Kevin/PycharmProjects/MLIntern2ndPipeline/Images/Images/sample.png")

    # 2. Get the connected domain of the picture
    cnt_cs1 = get_contours(img_cs1)
    cnt_cs2 = get_contours(img_cs2)

    # 3. Create a distance object
    hausdorff_sd = cv2.createHausdorffDistanceExtractor()

    #     # 4. Calculate the distance between contours

    d1 = hausdorff_sd.computeDistance(cnt_cs1, cnt_cs2)
    print("The distance to itself hausdorff\t d1=", d1)


if __name__ == '__main__':
    main()
