from skimage.color import rgb2gray
from sklearn.cluster import KMeans
import numpy as np
import cv2
import matplotlib.pyplot as plt
from scipy import ndimage

image = plt.imread('/Users/Kevin/PycharmProjects/MLIntern2ndPipeline/Images/scissor/1.jpeg')
gray = rgb2gray(image)

# Regional Based Segmentation- Global thresholding: two regions (object and background) with single threshold value.
gray_r = gray.reshape(gray.shape[0]*gray.shape[1])
for i in range(gray_r.shape[0]):
    if gray_r[i] > gray_r.mean():
        gray_r[i] = 1
    else:
        gray_r[i] = 0
gray = gray_r.reshape(gray.shape[0], gray.shape[1])
plt.imshow(gray, cmap='gray')
plt.show()


# Regional Based Segmentation- Local thresholding: many threshold values
gray = rgb2gray(image)
gray_r = gray.reshape(gray.shape[0]*gray.shape[1])
for i in range(gray_r.shape[0]):
    if gray_r[i] > gray_r.mean():
        gray_r[i] = 3
    elif gray_r[i] > 0.5:
        gray_r[i] = 2
    elif gray_r[i] > 0.25:
        gray_r[i] = 1
    else:
        gray_r[i] = 0
gray = gray_r.reshape(gray.shape[0], gray.shape[1])
plt.imshow(gray, cmap='gray')
plt.show()


# K means Image Segmentation based on Clustering
image = plt.imread('/Users/Kevin/PycharmProjects/MLIntern2ndPipeline/Images/scissor/1.jpeg')
pic_n = image.reshape(image.shape[0]*image.shape[1], image.shape[2])  # Convert image to 2D Array
# Here chosen 5 color clusters but you can chose whatever, segmentation improves by increasing # of clusters
kmeans = KMeans(n_clusters=5, random_state=0).fit(pic_n)  # fit k-means algorithm on reshaped array and get clusters
pic2show = kmeans.cluster_centers_[kmeans.labels_]
cluster_pic = pic2show.reshape(image.shape[0], image.shape[1], image.shape[2])
plt.imshow((cluster_pic * 255).astype(np.uint8))
plt.show()

