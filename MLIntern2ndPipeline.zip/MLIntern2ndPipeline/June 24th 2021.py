from skimage.color import rgb2gray
from sklearn.cluster import KMeans
import numpy as np
import cv2
import matplotlib.pyplot as plt
import cv2.xfeatures2d
import glob
import os
from scipy import ndimage

# 1. Edge detection on K-means -----------------------------------------------------------------------------------------
# Canny edge detection on kmeans:
kmeans = cv2.imread('/Users/Kevin/PycharmProjects/MLIntern2ndPipeline/Images/June 22nd 2021 Update /Image Segmentation/K means Image Segmentation based on Clustering.png')
edges = cv2.Canny(kmeans, 100, 200)
plt.subplot(121), plt.imshow(kmeans, cmap='gray')
plt.title('Original Image'), plt.xticks([]), plt.yticks([])
plt.subplot(122), plt.imshow(edges, cmap='gray')
plt.title('Edge Image'), plt.xticks([]), plt.yticks([])
plt.show()

# 2. Edge detection/Contouring on Stylization Filter
stylized_image = cv2.imread('/Users/Kevin/PycharmProjects/MLIntern2ndPipeline/Images/June 22nd 2021 Update /Non-Photorealistic Rendering/Stylization Filter (Watercolor type).png')
stylized_image = cv2.cvtColor(stylized_image, cv2.COLOR_BGR2GRAY)  # B&W
edges = cv2.Canny(stylized_image, 100, 200)  # Edge detection
# Contouring:
ret, thresh = cv2.threshold(edges, 127, 255, 0)
contours, hierarchy = cv2.findContours(thresh, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)
print("Number of contours = " + str(len(contours)))
print(contours[0])

cv2.drawContours(edges, contours, 4, (0, 255, 0), 3)

plt.subplot(121), plt.imshow(stylized_image, cmap='gray')
plt.title('Original Image'), plt.xticks([]), plt.yticks([])
plt.subplot(122), plt.imshow(edges, cmap='gray')
plt.title('Edge/Contours Image'), plt.xticks([]), plt.yticks([])
plt.show()

# 3 Adaptive and Otsu’s thresholding on K means image segmentation
img = cv2.imread('/Users/Kevin/PycharmProjects/MLIntern2ndPipeline/Images/June 22nd 2021 Update /Image Segmentation/K means Image Segmentation based on Clustering.png', 0)
# adaptive thresholding
th1 = cv2.adaptiveThreshold(img,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY,11,2)
# Otsu's thresholding
ret2,th2 = cv2.threshold(img,0,255,cv2.THRESH_BINARY+cv2.THRESH_OTSU)
# Otsu's thresholding after Gaussian filtering
blur = cv2.GaussianBlur(img,(5,5),0)
ret3,th3 = cv2.threshold(blur,0,255,cv2.THRESH_BINARY+cv2.THRESH_OTSU)
# plot all the images and their histograms
images = [img, 0, th1,
          img, 0, th2,
          blur, 0, th3]
titles = ['Original Noisy Image','Histogram','Adaptive Thresholding (v=127)',
          'Original Noisy Image','Histogram',"Otsu's Thresholding",
          'Gaussian filtered Image','Histogram',"Otsu's Thresholding"]
for i in range(3):
    plt.subplot(3,3,i*3+1),plt.imshow(images[i*3],'gray')
    plt.title(titles[i*3]), plt.xticks([]), plt.yticks([])
    plt.subplot(3,3,i*3+2),plt.hist(images[i*3].ravel(),256)
    plt.title(titles[i*3+1]), plt.xticks([]), plt.yticks([])
    plt.subplot(3,3,i*3+3),plt.imshow(images[i*3+2],'gray')
    plt.title(titles[i*3+2]), plt.xticks([]), plt.yticks([])
plt.show()

# 4. Edge preserving filter followed by matching
img1 = cv2.imread('Images/Images/Screenshot 2021-05-11 at 11.19.45 AM.png')  # Query image (already b&w)
# Edge preserved image
img2 = cv2.imread('/Users/Kevin/PycharmProjects/MLIntern2ndPipeline/Images/June 22nd 2021 Update /Non-Photorealistic Rendering/Edge Preserving Filter.png')  # Train Image (already b&w)
img2 = cv2.bilateralFilter(img2, 5, 75, 75)  # edge preserving blur of train image
# cv.imshow("Blur", img2)
# cv.waitKey(0)

img2, g, r = cv2.split(img2)
img1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)  # lighter means more concentration of that color


# Initiate SIFT detector
sift = cv2.xfeatures2d.SIFT_create()

# find the key points and descriptors with SIFT
kp1, des1 = sift.detectAndCompute(img1, None)
kp2, des2 = sift.detectAndCompute(img2, None)

# BFMatcher with default params
bf = cv2.BFMatcher()
matches = bf.knnMatch(des1, des2, k=2)

# Apply ratio test
good = []
for m, n in matches:  # Limits distance
    if m.distance < 0.80*n.distance:
        good.append([m])

# cv.drawMatchesKnn expects list of lists as matches.
img3 = cv2.drawMatchesKnn(img1, kp1, img2, kp2, good, None, flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS)

cv2.imshow("Img1", img1)
cv2.imshow("Img2", img2)
cv2.imshow("Matches", img3)
cv2.waitKey(0)
cv2.destroyAllWindows()

# Do contouring on adaptive thresholding of k means image segmentation
