import cv2

#  Edge Preserving Filter ( edgePreservingFilter )
image = cv2.imread('/Users/Kevin/PycharmProjects/MLIntern2ndPipeline/Images/scissor/1.jpeg')
dst = cv2.edgePreservingFilter(image, flags=1, sigma_s=60, sigma_r=0.4)
# cv2.imshow('Edge Preserving', dst)
# cv2.waitKey(0)

# Detail Enhancing Filter ( detailEnhance )
dst = cv2.detailEnhance(image, sigma_s=10, sigma_r=0.15)
# cv2.imshow('Details enhanced', dst)
# cv2.waitKey(0)

# Pencil Sketch Filter ( pencilSketch )
image = cv2.imread('/Users/Kevin/PycharmProjects/MLIntern2ndPipeline/Images/scissor/1.jpeg')
dst_gray, dst_color = cv2.pencilSketch(image, sigma_s=60, sigma_r=0.07, shade_factor=0.05)
# cv2.imshow('Pencil Sketch', dst_gray)
# cv2.waitKey(0)

# Stylization Filter ( stylization ): Produces watercolor type version of image
image = cv2.imread('/Users/Kevin/PycharmProjects/MLIntern2ndPipeline/Images/scissor/1.jpeg')
dst1 = cv2.stylization(image, sigma_s=60, sigma_r=0.07)
cv2.imshow('Stylization Filter', dst1)
cv2.waitKey(0)
