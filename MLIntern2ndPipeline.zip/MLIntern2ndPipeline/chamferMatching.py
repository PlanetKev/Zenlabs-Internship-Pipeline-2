import numpy as np
import cv2

frame = cv2.imread('/Images/scissor/1.jpeg')
frame = cv2.GaussianBlur(frame, (13, 13), 0)
frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
frame = cv2.adaptiveThreshold(frame, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2)

templ = cv2.imread("/Images/Images/sample.png")

cannyframe = cv2.Canny(frame, 5, 50, apertureSize=3)
cannytempl = cv2.Canny(templ, 5, 50, apertureSize=3)

cv2.imshow("cannyframe",cannyframe)
cv2.imshow("cannytempl", cannytempl)

cv2.waitKey(0)

# Function not working
cv2.chamferMatching(cannytempl, cannyframe)
